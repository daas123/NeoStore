//
//  HomeCollectionViewCell.swift
//  Neostore
//
//  Created by Neosoft on 18/08/23.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var cellImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
